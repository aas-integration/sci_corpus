package org.nd4j.linalg.factory;


/**
 * @author Audrey Loeffel
 */
public abstract class BaseSparseNDArrayFactory extends BaseNDArrayFactory {
    // TODO override needed methods
}
