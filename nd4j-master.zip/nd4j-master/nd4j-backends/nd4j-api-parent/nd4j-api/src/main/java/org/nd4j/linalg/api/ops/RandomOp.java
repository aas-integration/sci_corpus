package org.nd4j.linalg.api.ops;

/**
 * @author raver119@gmail.com
 */
public interface RandomOp extends Op {

}
