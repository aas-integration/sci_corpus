package org.nd4j.linalg.api.blas.impl;

/**
 * @author Audrey Loeffel
 */
public abstract class SparseBaseLevel {

}
