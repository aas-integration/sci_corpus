jscience
========

This is a clone of JScience 4.3.1 from the SVN repo which adds proper OSGification of the library.
