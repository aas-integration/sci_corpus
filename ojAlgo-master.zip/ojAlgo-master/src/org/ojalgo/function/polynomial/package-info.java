/**
 * package-info
 *
 * @author apete
 */
package org.ojalgo.function.polynomial;
