package org.nd4j.linalg.compression;

/**
 * @author raver119@gmail.com
 */
public enum CompressionType {
    LOSSLESS, LOSSY,
}
