# JLargeArrays project has been moved to [gitlab.com](https://gitlab.com/ICM-VisLab/JLargeArrays). 

JLargeArrays
============

JLargeArrays is a pure-java library of one-dimensional arrays that can store up to 2<sup>63</sup> elements.

## Sources and Binaries

### JLargeArrays 1.4

[JLargeArrays-1.4.jar](http://search.maven.org/remotecontent?filepath=pl/edu/icm/JLargeArrays/1.4/JLargeArrays-1.4.jar) 

[JLargeArrays-1.4-javadoc.jar](http://search.maven.org/remotecontent?filepath=pl/edu/icm/JLargeArrays/1.4/JLargeArrays-1.4-javadoc.jar) 

[JLargeArrays-1.4-sources.jar](http://search.maven.org/remotecontent?filepath=pl/edu/icm/JLargeArrays/1.4/JLargeArrays-1.4-sources.jar) 

JLargeArrays is available on maven central as

        <dependency>
            <groupId>pl.edu.icm</groupId>
            <artifactId>JLargeArrays</artifactId>
            <version>1.4</version>
        </dependency>

##  JavaDoc
The documentation is available at [apidocs](http://icmvis.github.io/JLargeArrays/apidocs/).
