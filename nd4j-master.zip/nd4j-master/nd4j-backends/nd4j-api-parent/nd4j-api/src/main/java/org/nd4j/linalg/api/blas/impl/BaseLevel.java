package org.nd4j.linalg.api.blas.impl;

/**
 * Provides auxillary methods for
 * blas to databuffer interactions
 * @author Adam Gibson
 */
public abstract class BaseLevel {

}

