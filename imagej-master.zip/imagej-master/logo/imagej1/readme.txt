This directory contains logos and icons for ImageJ1.

The ImageJ1 icon is based on a photograph by Tom Grill
(http://www.tomgrill.com/) of a Hartnack microscope, circa 1870's:
   http://www.arsmachina.com/s-hart1209.htm

The ImageJ1 logo (imagej-logo.gif) was created using a macro:
   http://imagej.net/macros/MakeImageJLogo.txt
