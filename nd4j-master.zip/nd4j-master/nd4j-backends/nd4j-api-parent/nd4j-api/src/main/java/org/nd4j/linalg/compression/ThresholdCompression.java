package org.nd4j.linalg.compression;

public class ThresholdCompression {
    public static final int FLEXIBLE_ENCODING = 0;
    public static final int BITMAP_ENCODING = 1;
}
