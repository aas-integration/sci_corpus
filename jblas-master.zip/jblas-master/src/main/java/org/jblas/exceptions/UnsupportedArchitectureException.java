package org.jblas.exceptions;

/**
 * <one line description>
 * <p/>
 * <longer description>
 * <p/>
 * User: mikio
 * Date: 2/13/13
 * Time: 12:28 PM
 */
public class UnsupportedArchitectureException extends RuntimeException {
  public UnsupportedArchitectureException(String message) {
    super(message);
  }
}
