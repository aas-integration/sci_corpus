/**
 * <p>
 * This package loosely corresponds to (extends) the packages: java.io.*, java.nio.*, java.net.* and sun.net.*
 * </p>
 *
 * @author apete
 */
package org.ojalgo.netio;
