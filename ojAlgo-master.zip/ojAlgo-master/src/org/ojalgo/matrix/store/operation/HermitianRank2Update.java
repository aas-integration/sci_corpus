/*
 * Copyright 1997-2017 Optimatika (www.optimatika.se)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package org.ojalgo.matrix.store.operation;

import java.math.BigDecimal;

import org.ojalgo.scalar.ComplexNumber;

/**
 * [A] -= ([a][b]<sup>c</sup>+[b][a]<sup>c</sup>) <br>
 * [A] is assumed to be hermitian (square symmetric) [A] = [A]<sup>C</sup>. <br>
 * <sup>C</sup> == conjugate transpose
 *
 * @author apete
 */
public final class HermitianRank2Update extends MatrixOperation {

    public static final HermitianRank2Update SETUP = new HermitianRank2Update();

    public static int THRESHOLD = 256;

    public static void invoke(final BigDecimal[] data, final int firstColumn, final int columnLimit, final BigDecimal[] vector1, final BigDecimal[] vector2) {

        final int structure = vector1.length;

        BigDecimal tmpVal1j;
        BigDecimal tmpVal2j;

        int tmpIndex;
        for (int j = firstColumn; j < columnLimit; j++) {

            tmpVal1j = vector1[j];
            tmpVal2j = vector2[j];

            tmpIndex = j + (j * structure);
            for (int i = j; i < structure; i++) {
                data[tmpIndex] = data[tmpIndex].subtract(vector2[i].multiply(tmpVal1j).add(vector1[i].multiply(tmpVal2j)));
                tmpIndex++;
            }
        }
    }

    public static void invoke(final ComplexNumber[] data, final int firstColumn, final int columnLimit, final ComplexNumber[] vector1,
            final ComplexNumber[] vector2) {

        final int structure = vector1.length;

        ComplexNumber tmpVal1j;
        ComplexNumber tmpVal2j;

        int tmpIndex;
        for (int j = firstColumn; j < columnLimit; j++) {

            tmpVal1j = vector1[j].conjugate();
            tmpVal2j = vector2[j].conjugate();

            tmpIndex = j + (j * structure);
            for (int i = j; i < structure; i++) {
                data[tmpIndex] = data[tmpIndex].subtract(vector2[i].multiply(tmpVal1j).add(vector1[i].multiply(tmpVal2j)));
                tmpIndex++;
            }
        }
    }

    public static void invoke(final double[] data, final int firstColumn, final int columnLimit, final double[] vector1, final double[] vector2) {

        final int structure = vector1.length;

        double tmpVal1j;
        double tmpVal2j;

        int tmpIndex;
        for (int j = firstColumn; j < columnLimit; j++) {

            tmpVal1j = vector1[j];
            tmpVal2j = vector2[j];

            tmpIndex = j + (j * structure);
            for (int i = j; i < structure; i++) {
                data[tmpIndex++] -= ((vector2[i] * tmpVal1j) + (vector1[i] * tmpVal2j));
            }
        }
    }

    private HermitianRank2Update() {
        super();
    }

    @Override
    public int threshold() {
        return THRESHOLD;
    }

}
