package org.jblas;

/**
 * Information class which holds the version String
 *
 * User: mikio
 * Date: 2/12/13
 * Time: 3:28 PM
 */
public class Info {
  public static String VERSION = "1.2.4";
}
