/**
 * package-info
 *
 * @author apete
 */
package org.ojalgo.finance;
